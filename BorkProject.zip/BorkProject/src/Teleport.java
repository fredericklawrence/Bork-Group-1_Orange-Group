/**
 *
 * @author Alex
 */
public class Teleport {
    
    /**
     *
     *
     * @param takes in a random room
     * Method that teleports the player to a diffrent room.
     */
    Room pickRoom(Room room)
    {
        return room;
    }
}
